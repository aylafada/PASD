package StudiKasus2;

public class DLLPesanan {
    nodePesanan head, tail;
    int size;

    public DLLPesanan() {
        head = null;
        tail = null;
        size = 0;
    }

    public boolean isEmpty() {
        return head == null;
    }

    //enqueue
    public void tambahPesanan(pesanan data) {
        nodePesanan newNode = new nodePesanan(data);

        if(isEmpty()) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    public void sorting() {
        if (isEmpty() || head == tail) {
            return;
        }
        boolean swap;
        do { 
            swap = false;
            nodePesanan current = head;
            while (current.next != null) {
                if (current.data.namaPesanan.compareToIgnoreCase(current.next.data.namaPesanan) > 0) {
                    pesanan temp = current.data;
                    current.data = current.next.data;
                    current.next.data = temp;
                    swap = true;
                }
                current = current.next;
            } 
        } while(swap);
    }

    void print() {
        if(isEmpty()) {
            System.out.println("Belum ada pesanan");
            return;
        }
        System.out.println("========================================");
        System.out.println("LAPORAN PESANAN (URUT NAMA PESANAN)");
        System.out.println("========================================");
        System.out.printf("%-10s %-20s %-10s\n", "Kode", "Nama Pesanan", "Harga");
        nodePesanan current = head;
        while (current != null) {
            System.out.printf("%-10d %-20s %-10d\n", current.data.kodePesanan, current.data.namaPesanan, current.data.harga);
            current = current.next;
        }
    }

    //2. print reverse
    public void printReverse() {
        nodePesanan current = tail;
        while(current != null) {
            System.out.println(current.data.namaPesanan);
            current = current.prev;
        }
    }

    //3. hapus pesanan terakhir
    public void removeLast(){
        if(isEmpty()){
            System.out.println("Kosong");
            return;
        }

        System.out.println(
            "Pesanan dihapus : " +tail.data.namaPesanan);
        if(head == tail){
            head = tail = null;
        } else {
            tail = tail.prev;
            tail.next = null;
        }
        size--;
    }

    //5. total pendapatan
    public int totalPendapatan() {
        int total = 0;
        nodePesanan current = head;
        while(current != null) {
            total += current.data.harga;
            current = current.next;
        }
        return total;
    }
    
    //6. pesanan termahal
    public void pesananTermahal(){
        if(isEmpty()){
            System.out.println("Kosong");
            return;
        }

        nodePesanan current = head;
        pesanan max = head.data;
        while(current != null){
            if(current.data.harga > max.harga){
                max = current.data;
            }
            current = current.next;
        }
        System.out.println("Pesanan Termahal");
        System.out.println(max.namaPesanan);
        System.out.println(max.harga);
    }

    //7. Cari Pesanan
    public void cariPesanan(String nama) {
        nodePesanan current = head;
        while(current != null) {
            if(current.data.namaPesanan.equalsIgnoreCase(nama)) {
                System.out.println("Ditemukan");
                System.out.println(current.data.kodePesanan);
                System.out.println(current.data.namaPesanan);
                System.out.println(current.data.harga);
                return;
            }
            current = current.next;
        }
        System.out.println("Tidak Ditemukan");
    }

    //8. insert after
    public void insertAfter(String namaCari, pesanan dataBaru) {
        nodePesanan current = head;
        while(current != null){
            if(current.data.namaPesanan.equalsIgnoreCase(namaCari)){
                nodePesanan newNode = new nodePesanan(dataBaru);
                if(current == tail){
                    current.next = newNode;
                    newNode.prev = current;
                    tail = newNode;
                } else {
                    newNode.next = current.next;
                    newNode.prev = current;
                    current.next.prev = newNode;
                    current.next = newNode;
                }
                System.out.println("Pesanan berhasil disisipkan");
                return;
            }
            current = current.next;
        }
        System.out.println("Pesanan tidak ditemukan");
    }

    //9. tampilkan head dan tail
    public void tampilHeadTail() {
        if(isEmpty()) {
            System.out.println("Belum ada pesanan");
            return;
        }
        System.out.println("Pesanan Pertama");
        System.out.println("Kode : " + head.data.kodePesanan);
        System.out.println("Nama : " + head.data.namaPesanan);
        System.out.println("Harga : " + head.data.harga);

        System.out.println();

        System.out.println("Pesanan Terakhir");
        System.out.println("Kode : " + tail.data.kodePesanan);
        System.out.println("Nama : " + tail.data.namaPesanan);
        System.out.println("Harga : " + tail.data.harga);
    }

    //10. pesanan termurah
    public void pesananTermurah() {
        if(isEmpty()) {
            System.out.println("Belum ada pesanan");
            return;
        }
        nodePesanan current = head;
        pesanan min = head.data;
        while(current != null) {
            if(current.data.harga < min.harga) {
                min = current.data;
            }
            current = current.next;
        }
        System.out.println("Pesanan Termurah");
        System.out.println("Kode : " + min.kodePesanan);
        System.out.println("Nama : " + min.namaPesanan);
        System.out.println("Harga : " + min.harga);
    }

    //11. hapus berdasarkan nama pesanan
    public void hapusPesanan(String nama) {
        if(isEmpty()) {
            System.out.println("Belum ada pesanan");
            return;
        }
        nodePesanan current = head;
        while(current != null) {
            if(current.data.namaPesanan.equalsIgnoreCase(nama)) {
                System.out.println("Pesanan dihapus : " + current.data.namaPesanan);
                if(current == head) {
                    head = head.next;
                    if(head != null) {
                        head.prev = null;
                    }
                } else if(current == tail) {
                    tail = tail.prev;
                    if(tail != null) {
                        tail.next = null;
                    }
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                size--;
                return;
            }
            current = current.next;
        }
        System.out.println("Pesanan tidak ditemukan");
    }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
  

    

}
