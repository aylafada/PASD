package StudiKasus2;

import java.util.Scanner;

public class DLLMain {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DLLPembeli antrian = new DLLPembeli();
        DLLPesanan daftarPesanan = new DLLPesanan();
        
        int noAntrian = 1;
        int pilih;

        do { 
            System.out.println("==========================================");
            System.out.println("        SISTEM ANTRIAN ROYAL DELISH       ");
            System.out.println("==========================================");
            System.out.println("1. Tambah Antrian");
            System.out.println("2. Cetak Antrian");
            System.out.println("3. Hapus Antrian dan Pesan");
            System.out.println("4. Laporan Pesanan");
            // 1. System.out.println("5. Cari pembeli");
            // 2. Cari terbalik
            //8. sisipkan pesanan (insert after)
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            pilih = sc.nextInt();
            sc.nextLine();
            
            switch (pilih) {
                case 1:
                    System.out.print("Nama Pembeli: ");
                    String nama = sc.nextLine();
                    System.out.print("No HP: ");
                    String hp = sc.nextLine();
                    pembeli pembeliBaru = new pembeli(noAntrian, nama, hp);
                    antrian.enqueue(pembeliBaru);
                    System.out.println("Antrian berhasil ditambahkan dengan nomor: " +noAntrian +"\n");
                    noAntrian++;
                    break;
                case 2:
                    antrian.printAntrian();
                    System.out.println();
                    break;
                case 3:
                    pembeli pembeliDilayani = antrian.dequeue();
                    if (pembeliDilayani != null) {
                        System.out.print("Kode Pesanan: ");
                        int kode = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Nama Pesanan: ");
                        String namaPesanan = sc.nextLine();
                        System.out.print("Harga       : ");
                        int harga = sc.nextInt();
                        sc.nextLine();
                        pesanan pesananBaru = new pesanan(kode, namaPesanan, harga);
                        daftarPesanan.tambahPesanan(pesananBaru);
                        System.out.println(pembeliDilayani.namaPembeli +" telah memesan " +namaPesanan);
                    }
                    break;
                case 4:
                    daftarPesanan.sorting();
                    daftarPesanan.print();
                    System.out.println();
                    break;
                // 1. case 5:
                //     System.out.println("Nama: ");
                //     String cari = sc.nextLine();
                //     antrian.cariPembeli(cari);
                //     break;
                // 2. case 6: 
                //     daftarPesanan.printReverse();
                //     break;
                // 3. case 7:
                //     daftarPesanan.removeLast();
                //     break;
                // 4. case 8:
                //     System.out.println("Jumlah Antrian: " +antrian.jumlahAntrian());
                //     break;
                // 5. case 9:
                //     System.out.println("Total Pendapatan : " +daftarPesanan.totalPendapatan());
                //     break;
                // 6. case 10:
                //     daftarPesanan.pesananTermahal();
                //     break;
                // 7. case 11:
                //     System.out.print("Nama Pesanan : ");
                //     String cariPesanan =
                //     sc.nextLine();
                //     daftarPesanan.cariPesanan(cariPesanan);
                //     break;
                // 8. case 12:
                //     System.out.print("Disisipkan setelah : ");
                //     String namaCari = sc.nextLine();
                //     System.out.print("Kode Pesanan Baru : ");
                //     int kode = sc.nextInt();
                //     sc.nextLine();
                //     System.out.print("Nama Pesanan Baru : ");
                //     String namaBaru = sc.nextLine();
                //     System.out.print("Harga : ");
                //     int harga = sc.nextInt();
                //     sc.nextLine();
                //     pesanan baru = new pesanan(kode, namaBaru, harga);
                //     daftarPesanan.insertAfter(namaCari, baru);
                //     break;
                // 9. case 13:
                //     daftarPesanan.tampilHeadTail();
                //     break;
                // 10. case 13:
                //     daftarPesanan.pesananTermurah();
                //     break;
                // 11. case 14:
                //     System.out.print("Nama pesanan yang dihapus : ");
                //     String hapus = sc.nextLine();
                //     daftarPesanan.hapusPesanan(hapus);
                //     break;
                // 12. case 15:
                //     System.out.print("Nomor antrian : ");
                //     int cari = sc.nextInt();
                //     sc.nextLine();
                //     antrian.cariAntrian(cari);
                //     break;
                // 13. case 16:
                //     antrian.pembeliTerakhir();
                //     break;
                case 0:
                    System.out.println("Terima kasih");
                    break;
                default:
                    System.out.println("Menu tidak tersedia");
            }
        } while (pilih != 0);
    }
}
